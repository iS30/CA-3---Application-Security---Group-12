# from django.db import models

# from core.models import ArchiveResult

# class FaviconResultManager(models.Manager):
#     def get_queryset(self):
#         return super().get_queryset().filter(extractor='favicon')


# class FaviconResult(ArchiveResult):
#     objects = FaviconResultManager()

#     class Meta:
#         proxy = True
