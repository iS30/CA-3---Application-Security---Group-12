# from django.db import models

# from core.models import ArchiveResult

# class SinglefileResultManager(models.Manager):
#     def get_queryset(self):
#         return super().get_queryset().filter(extractor='singlefile')


# class SinglefileResult(ArchiveResult):
#     objects = SinglefileResultManager()

#     class Meta:
#         proxy = True
