# assets/

This folder contains assets used by the Jekyll Static Site Generator for ArchiveBox.io.

It cannot be moved or renamed or the custom CSS on ArchiveBox.io will break.
