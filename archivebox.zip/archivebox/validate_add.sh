#!/bin/bash

url="$1"

# Only allow HTTP or HTTPS URLs
if [[ ! "$url" =~ ^https?:// ]]; then
    echo "Invalid URL: must start with http:// or https://"
    exit 1
fi

docker exec archivebox archivebox add "$url"
